import { LightningElement,wire,track } from 'lwc';
import   getStuckedStages from '@salesforce/apex/BarChartController.getStuckedStages';
import ChartDataLabels from '@salesforce/resourceUrl/ChartjsPluginDataLabels';
export default class StuckOpportunityStage extends LightningElement {

chartConfiguration;


@wire(getStuckedStages)
getStuckedStages({ error, data }) {
//console.log('getOpportunities'+getOpportunities);
if (error) {
    this.error = error;
    this.chartConfiguration = undefined;
} else if (data) {
   console.log('data'+JSON.stringify(data));

   const objStr=JSON.parse(data);
   console.log('objstr'+objStr);
  
    let chartDurationData = [];
    let chartColor=[];
     let chartLabel = [];
      var dynamicColors = function() {
            var r = Math.floor(Math.random() * 255);
            var g = Math.floor(Math.random() * 255);
            var b = Math.floor(Math.random() * 255);
            return "rgb(" + r + "," + g + "," + b + ")";
         };
   for(const obj in objStr){
       chartLabel.push(obj);
       chartDurationData.push(objStr[obj]); 
       chartColor.push(dynamicColors());
   }
   console.log('chartDurationData'+chartDurationData);
  console.log('chartlabel'+chartLabel);

  
  
     this.chartConfiguration = {
        type: 'bar',
        data: {
            labels: chartLabel,
            datasets: [{
                label: 'Opportunity Stage Stucked (in Days)',
                backgroundColor:chartColor,
                data: chartDurationData,
              //  fill: false,
              //  lineTension:0
            }],

        },
        options: { 
            scales: {
                xAxes: [
                        {
                            beginAtZero: true,
                            ticks: {
                                autoSkip: false
                            }
                        }
                    ],
            yAxes: [{
                ticks: {
                    beginAtZero: true,
                    stepSize: 10,
                    min: 0,
                    max: 100
                }
            }]
        }},
         plugins: {
    datalabels: {
        color: "orange",
        labels: {
            title: {
                font: {
                    weight: "bold"
                }
            }
        }
    }
}
    };
    console.log('data => ', data);
    this.error = undefined;
}
 }
}